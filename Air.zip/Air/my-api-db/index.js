const db = require('./db');

async function loadData() {
  const response = await fetch("https://api-challenge.odpt.org/api/v4/odpt:FlightInformationDeparture?odpt:operator=odpt.Operator:HND-TIAT&acl:consumerKey=9nu8sb4pbsymncsjjmozx3e8wantkjy4yoefmvreuhwmvrbsuatn3g5oy6dzl8bk"); // Node18+ならOK
  const data = await response.json();
  console.log(data);
}

loadData();
