const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('mydata.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS flights (
    flightNumber TEXT,
    departure TEXT,
    arrival TEXT
  )`);
});

module.exports = db;
